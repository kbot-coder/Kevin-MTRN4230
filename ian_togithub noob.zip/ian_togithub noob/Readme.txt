Dear Demonstrator that mark my assignment...

i've run this code numerous time in various computer ( tyree, blockhouse, personal pc) 
it works perfectly and still within the time limit

if some unforseen accident happen during my attempt to save and zip this assignment 1 
(mistype during saving /misclick / sent the wrong things) tell me so i can fix it / sent 
the right file

may God bless you dear kind soul

thanks for your attention 