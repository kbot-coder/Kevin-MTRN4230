Unfinish:

Automations
  	auto load
  	auto pick
	auto stack